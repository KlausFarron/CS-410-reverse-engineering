#include <iostream>
#include <string>
#include <limits> // For discarding invalid input from the input stream

using namespace std;

// Security vulnerability: Fixed-size character array can cause a buffer overflow
// Security fix: Use string to prevent writing beyond the allocated array
string username;

// Client names from the project.
char name1[] = "Bob Jones";
char name2[] = "Sarah Davis";
char name3[] = "Amy Friendly";
char name4[] = "Johnny Smith";
char name5[] = "Carol Spears";

// Current services: 1 = Brokerage, 2 = Retirement
int num1 = 1;
int num2 = 2;
int num3 = 1;
int num4 = 1;
int num5 = 2;

// Values used by the menu and client updates
int answer = 0;
int choice = 0;
int changechoice = 0;
int newservice = 0;

// Function declarations
int CheckUserPermissionAccess();
void DisplayInfo();
void ChangeCustomerChoice();

// main function
int main() {
    // Added opening output statement
    cout << "Created by Aleksandr Donovan for 410 software engineering." << endl;

    cout << "Hello, welcome to the SNHU Investments.\n";

    // Security vulnerability: Unlimited login attempts allow repeated password guessing
    // Security fix: Limit failed login attempts to three before exiting the program
    int attempts = 0;
    const int maxAttempts = 3;

    do {
        answer = CheckUserPermissionAccess();

        if (answer == 0) {
            cout << "Input ended. Exiting program.\n";
            return 1;
        }

        if (answer != 1) {
            attempts++;

            if (attempts < maxAttempts) {
                cout << "Invalid Password. Please try again\n";
            }
            else {
                cout << "Maximum login attempts reached. Access denied.\n";
                return 1;
            }
        }
    } while (answer != 1);


    // Repeat the menu until the user selects option 3
    do {
        cout << "What would you like to do?\n";
        cout << "DISPLAY the client list (enter 1)\n";
        cout << "CHANGE a client's choice (enter 2)\n";
        cout << "Exit the program.. (enter 3)\n";

        // Security vulnerability: Missing input validation for the menu
        // Security fix: Reject invalid input and input options outside of range
        if (!(cin >> choice)) {
            if (cin.eof()) {
                return 0;
            }

            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a number between 1 and 3.\n";
            continue;
        }

        // Check and reject additional characters after the number
        string extraInput;
        getline(cin, extraInput);

        if (extraInput.find_first_not_of(" \t") != string::npos) {
            cout << "Invalid input. Please enter only one number.\n";
            continue;
        }

        // Check if the number is between 1 and 3
        if (choice < 1 || choice > 3) {
            cout << "Invalid choice. Please enter a number between 1 and 3.\n";
            continue;
        }

        cout << "You chose " << choice << endl;


        // Display client list
        if (choice == 1) {
            DisplayInfo();
        }
        // edit the customer choice
        else if (choice == 2) {
            ChangeCustomerChoice();
        }
    } while (choice != 3); // exit the program

    return 0;
}

// Function to check user permissions
int CheckUserPermissionAccess() {
    string password = "";
    int result = 0;

    cout << "Enter your username:\n";
    if (!(cin >> username)) {
        return 0;
    }

    // Security fix: Reject usernames longer than 19 characters
    if (username.length() > 19) {
        cout << "Username is too long. Maximum length is 19 characters.\n";
        return 2;
    }

    cout << "Enter your password:\n";
    if (!(cin >> password)) {
        return 0;
    }

    // Security vulnerability: The password is hard-coded and uses short, predictable sequence is easy to guess
    // Security vulnerability: The username is collected but never verified
    // Recommended fix: Secure authentication system that requires stronger passwords.
    // A stronger password would reduce guessing risks but does not fix the underlining vulnerability 
    // compare returns 0 when the password matches
    result = password.compare("123");

    if (result == 0) {
        return 1;
    }
    else {
        return 2;
    }
}

// Function to display client info
void DisplayInfo() {
    // Display each client's current service choice
    cout << "  Client's Name   Service Selected (1 = Brokerage, 2 = Retirement)"
        << endl;

    cout << "1. " << name1 << " selected option " << num1 << endl;
    cout << "2. " << name2 << " selected option " << num2 << endl;
    cout << "3. " << name3 << " selected option " << num3 << endl;
    cout << "4. " << name4 << " selected option " << num4 << endl;
    cout << "5. " << name5 << " selected option " << num5 << endl;
}

void ChangeCustomerChoice() {
    cout << "Enter the number of the client that you wish to change\n";

    // Security vulnerability: Client selection does not verify if the input is valid
    // Security fix: Reject nonnumeric input and client numbers outside 1 through 5
    // The validation would need to be updated if the application expands to allow clients to be added or removed
    if (!(cin >> changechoice)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid input. Please enter a number between 1 and 5.\n";
        return;
    }

    // Security fix: Reject additional characters after the client number
    string extraInput;
    getline(cin, extraInput);

    if (extraInput.find_first_not_of(" \t") != string::npos) {
        cout << "Invalid input. Please enter only one client number.\n";
        return;
    }

    if (changechoice < 1 || changechoice > 5) {
        cout << "Invalid client number. Please select a number between 1 and 5.\n";
        return;
    }

    cout << "Please enter the client's new service choice "
        << "(1 = Brokerage, 2 = Retirement)\n";

    // Security vulnerability: Service selection does not verify if the input is valid 
    // Security fix: Reject nonnumeric input and service options outside 1 and 2
    if (!(cin >> newservice)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid input. Please enter 1 or 2.\n";
        return;
    }

    // Security fix: Reject additional characters after the service number
    getline(cin, extraInput);

    if (extraInput.find_first_not_of(" \t") != string::npos) {
        cout << "Invalid input. Please enter only 1 or 2.\n";
        return;
    }

    // Check if the service selection is valid
    if (newservice < 1 || newservice > 2) {
        cout << "Invalid service choice. Please select 1 or 2.\n";
        return;
    }

    // Update the selected client's service
    if (changechoice == 1) {
        num1 = newservice;
    }
    else if (changechoice == 2) {
        num2 = newservice;
    }
    else if (changechoice == 3) {
        num3 = newservice;
    }
    else if (changechoice == 4) {
        num4 = newservice;
    }
    else if (changechoice == 5) {
        num5 = newservice;
    }
}
