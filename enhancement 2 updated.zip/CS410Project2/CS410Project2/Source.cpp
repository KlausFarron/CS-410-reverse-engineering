#include <iostream>
#include <string>
#include <limits>           // For discarding invalid input from the input stream
#include <unordered_map>    // For storing clients by client ID
#include <vector>           // For holding client IDs while sorting
#include <algorithm>        // For sort()
#include <cctype>           // For isalpha() and tolower()

using namespace std;

// Uses string instead of a fixed-size char array to prevent buffer overflows
string username;

// Structure to hold one client's information
struct Client {
    string name;
    int service; // 1 = Brokerage, 2 = Retirement
};

// Stores all clients, keyed by client ID
unordered_map<int, Client> clients = {
    {1, {"Bob Jones", 1}},
    {2, {"Sarah Davis", 2}},
    {3, {"Amy Friendly", 1}},
    {4, {"Johnny Smith", 1}},
    {5, {"Carol Spears", 2}}
};

// The ID given to the next new client
int nextClientId = 6; // Counts up and is never reused

// Maximum length allowed for a client name
const int MAX_NAME_LENGTH = 50;

// The menu number that exits the program
// Makes changing exit option easier
const int EXIT_OPTION = 6;

// Values used by the menu and client updates
int answer = 0;
int choice = 0;
int changechoice = 0;
int newservice = 0;

// Function declarations
int CheckUserPermissionAccess();
void DisplayInfo();
void ChangeCustomerChoice();
void AddClient();
int GetServiceChoice();
int GetClientId();
void DeleteClient();
void SearchClients();
string ToLower(string text);

// main function
int main() {
    // Added opening output statement
    cout << "Created by Aleksandr Donovan for 410 software engineering, enhanced for CS 499 capstone." << endl;

    cout << "Hello, welcome to the SNHU Investments.\n";

    // Limit failed login attempts to three to slow down password guessing
    int attempts = 0;
    const int maxAttempts = 3;

    do {
        answer = CheckUserPermissionAccess();

        if (answer == 0) {
            cout << "Input ended. Exiting program.\n";
            return 1;
        }

        if (answer != 1) {
            attempts++;

            if (attempts < maxAttempts) {
                cout << "Invalid Password. Please try again\n";
            }
            else {
                cout << "Maximum login attempts reached. Access denied.\n";
                return 1;
            }
        }
    } while (answer != 1);


    // Repeat the menu until the user selects the exit option
    do {
        cout << "What would you like to do?\n";
        cout << "DISPLAY the client list (enter 1)\n";
        cout << "CHANGE a client's choice (enter 2)\n";
        cout << "ADD a new client (enter 3)\n";
        cout << "DELETE a client (enter 4)\n";
        cout << "SEARCH clients by name (enter 5)\n";
        cout << "Exit the program.. (enter " << EXIT_OPTION << ")\n";

        // Reject nonnumeric menu input (e.g., "abc")
        if (!(cin >> choice)) {
            if (cin.eof()) {
                return 0;
            }

            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a number between 1 and " << EXIT_OPTION << ".\n";
            continue;
        }

        // Check and reject additional characters after the number
        string extraInput;
        getline(cin, extraInput);

        if (extraInput.find_first_not_of(" \t") != string::npos) {
            cout << "Invalid input. Please enter only one number.\n";
            continue;
        }

        // Check if the number is between 1 and exit number
        if (choice < 1 || choice > EXIT_OPTION) {
            cout << "Invalid choice. Please enter a number between 1 and " << EXIT_OPTION << ".\n";
            continue;
        }

        cout << "You chose " << choice << endl;


        // Display client list
        if (choice == 1) {
            DisplayInfo();
        }
        // edit the customer choice
        else if (choice == 2) {
            ChangeCustomerChoice();
        }
        // add a new client
        else if (choice == 3) {
            AddClient();
        }
        // delete a client
        else if (choice == 4) {
            DeleteClient();
        }
        // search clients by name
        else if (choice == 5) {
            SearchClients();
        }
    } while (choice != EXIT_OPTION); // exit the program

    return 0;
}

// Function to check user permissions
int CheckUserPermissionAccess() {
    string password = "";
    int result = 0;

    cout << "Enter your username:\n";
    if (!(cin >> username)) {
        return 0;
    }

    // Reject usernames longer than 19 characters
    if (username.length() > 19) {
        cout << "Username is too long. Maximum length is 19 characters.\n";
        return 2;
    }

    cout << "Enter your password:\n";
    if (!(cin >> password)) {
        return 0;
    }

    // Known limitation: The password is hard-coded and uses short, predictable sequence is easy to guess
    //                   The username is collected but never verified
    // Recommended fix: Secure authentication system that requires stronger passwords.
    // A stronger password would reduce guessing risks but does not fix the underlining vulnerability 
    // compare returns 0 when the password matches
    result = password.compare("123");

    if (result == 0) {
        return 1;
    }
    else {
        return 2;
    }
}

// Function to display client info
void DisplayInfo() {
    // Display each client's current service choice
    cout << "  Client's Name   Service Selected (1 = Brokerage, 2 = Retirement)"
        << endl;
    
    // Check for an empty list (e.g., every client was deleted)
    if (clients.empty()) {
        cout << "There are no clients to display.\n";
        return;
    }

    // Get every client ID from the map
    // An unordered_map has no set order, so the IDs are sorted before printing
    vector<int> ids;
    for (const auto& entry : clients) {
        ids.push_back(entry.first); // entry.first is the client ID
    }
    sort(ids.begin(), ids.end());

    // Print each client in ID order
    for (int id : ids) {
        cout << id << ". " << clients[id].name
            << " selected option " << clients[id].service << endl;
    }
}

// Function to change a client's service choice
void ChangeCustomerChoice() {
    cout << "Enter the number of the client that you wish to change\n";

    changechoice = GetClientId();
    if (changechoice == 0) {
        return; // The error message was already shown
    }

    // Find the client (GetClientId already checked that the ID exists)
    auto it = clients.find(changechoice);

    cout << "Please enter the client's new service choice "
        << "(1 = Brokerage, 2 = Retirement)\n";

    newservice = GetServiceChoice();
    if (newservice == 0) {
        return; // The error message was already shown
    }

    // Update the selected client's service
    it->second.service = newservice; // it->second is the Client
    cout << it->second.name << " is now set to option " << newservice << ".\n";
}

// Function to read and check a service choice
// Returns the service number, or 0 if the input is invalid
int GetServiceChoice() {
    int service = 0;

    // Reject nonnumeric input
    if (!(cin >> service)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid input. Please enter 1 or 2.\n";
        return 0;
    }

    // Reject additional characters after the service number
    string extraInput;
    getline(cin, extraInput);

    if (extraInput.find_first_not_of(" \t") != string::npos) {
        cout << "Invalid input. Please enter only 1 or 2.\n";
        return 0;
    }

    // Check if the service selection is valid
    if (service < 1 || service > 2) {
        cout << "Invalid service choice. Please select 1 or 2.\n";
        return 0;
    }

    return service;
}

// Function to add a new client with an automatically assigned ID
void AddClient() {
    string name;

    cout << "Enter the new client's full name:\n";
    if (!getline(cin, name)) {
        return;
    }

    // Check 1: Reject an empty name or a name with only spaces
    if (name.find_first_not_of(" \t") == string::npos) {
        cout << "Invalid name. The name cannot be empty.\n";
        return;
    }

    // Check 2: Reject names that are too long (e.g., pasted text)
    if (name.length() > MAX_NAME_LENGTH) {
        cout << "Invalid name. Maximum length is " << MAX_NAME_LENGTH << " characters.\n";
        return;
    }

    // Check 3: Allow only letters, spaces, hyphens, apostrophes, and periods (e.g., Mary-Jane O'Brien Jr.)
    // Check 4: Count the letters, so a name like "- -" is rejected
    int letterCount = 0;
    for (char c : name) {
        if (isalpha(static_cast<unsigned char>(c))) {
            letterCount++;
        }
        else if (c != ' ' && c != '-' && c != '\'' && c != '.') {
            cout << "Invalid name. Use only letters, spaces, hyphens (-), apostrophes ('), and periods (.).\n";
            return;
        }
    }

    if (letterCount == 0) {
        cout << "Invalid name. The name must contain at least one letter.\n";
        return;
    }

    cout << "Please enter the client's service choice "
        << "(1 = Brokerage, 2 = Retirement)\n";

    int service = GetServiceChoice();
    if (service == 0) {
        return; // The error message already shown
    }

    // Add the client to the map and moves the counter to the next ID
    int newId = nextClientId;
    clients[newId] = { name, service };
    nextClientId++;

    cout << name << " was added as client number " << newId << ".\n";
}

// Function to read a client number and check that the client exists
// Returns the client ID, or 0 if the input is invalid
int GetClientId() {
    int id = 0;

    // Reject nonnumeric input and client numbers that do not exist
    if (!(cin >> id)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid input. Please enter a client number.\n";
        return 0;
    }

    // Reject additional characters after the client number
    string extraInput;
    getline(cin, extraInput);

    if (extraInput.find_first_not_of(" \t") != string::npos) {
        cout << "Invalid input. Please enter only one client number.\n";
        return 0;
    }

    // Check that the client ID exists in the map
    if (clients.find(id) == clients.end()) {
        cout << "No client found with number " << id << ".\n";
        return 0;
    }

    return id;
}

// Function to delete a client after the user confirms
void DeleteClient() {
    cout << "Enter the number of the client that you wish to delete\n";

    int id = GetClientId();
    if (id == 0) {
        return; // The error message was already shown
    }

    // Ask for confirmation before deleting
    string confirm;
    cout << "Are you sure you want to delete " << clients[id].name << "? (y/n)\n";
    if (!getline(cin, confirm)) {
        return;
    }

    // Delete only on "y" or "Y", otherwise cancel
    if (confirm != "y" && confirm != "Y") {
        cout << "Delete canceled. " << clients[id].name << " was not deleted.\n";
        return;
    }

    string deletedName = clients[id].name; // Save the name before the client is removed
    clients.erase(id);

    cout << deletedName << " (client number " << id << ") was deleted.\n";
}

// Function to return a lowercase copy of the text
string ToLower(string text) {
    for (char& c : text) {
        c = static_cast<char>(tolower(static_cast<unsigned char>(c)));
    }
    return text;
}

// Function to search clients by name (partial match, and ignores uppercase and lowercase)
void SearchClients() {
    string searchText;

    cout << "Enter all or part of the client's name:\n";
    if (!getline(cin, searchText)) {
        return;
    }

    // Check 1: Reject an empty search or a search with only spaces
    if (searchText.find_first_not_of(" \t") == string::npos) {
        cout << "Invalid search. Please enter at least one letter.\n";
        return;
    }

    // Check 2: Reject searches longer than any allowed name
    if (searchText.length() > MAX_NAME_LENGTH) {
        cout << "Invalid search. Maximum length is " << MAX_NAME_LENGTH << " characters.\n";
        return;
    }

    // Linear search: checks every client's name for the search text
    // The map is keyed by ID, so a name search has to look at each client (O(n))
    string lowerSearch = ToLower(searchText);
    vector<int> matches;
    for (const auto& entry : clients) {
        string lowerName = ToLower(entry.second.name); // entry.second is the Client
        if (lowerName.find(lowerSearch) != string::npos) {
            matches.push_back(entry.first); // Save the matching client ID
        }
    }

    if (matches.empty()) {
        cout << "No clients found matching \"" << searchText << "\".\n";
        return;
    }

    // Print every match in ID in order
    sort(matches.begin(), matches.end());
    cout << matches.size() << " client(s) found matching \"" << searchText << "\":\n";
    for (int id : matches) {
        cout << id << ". " << clients[id].name
            << " selected option " << clients[id].service << endl;
    }
}